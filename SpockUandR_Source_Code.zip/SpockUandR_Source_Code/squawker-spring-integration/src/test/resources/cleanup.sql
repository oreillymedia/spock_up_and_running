DELETE FROM mention;
DELETE FROM message;
DELETE FROM user;
